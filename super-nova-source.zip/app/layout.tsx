import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "SUPER 노바 | 부산 수산물 실시간 시세",
  description: "실시간 수산물 시세와 AI 가격 분석으로 바가지 걱정 없이 부산 수산시장을 즐기세요.",
  icons: {
    icon: "/favicon.svg",
    shortcut: "/favicon.svg",
  },
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="ko">
      <body>{children}</body>
    </html>
  );
}
